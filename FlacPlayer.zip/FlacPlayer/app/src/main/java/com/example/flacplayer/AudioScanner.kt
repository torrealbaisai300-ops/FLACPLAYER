package com.example.flacplayer

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile

private val AUDIO_EXTENSIONS = setOf(
    "flac",
    "mp3",
    "m4a",
    "mp4",
    "aac",
    "ogg",
    "oga",
    "opus",
    "wav",
    "wave",
    "wma",
    "ape",
    "alac"
)

fun scanAudioFiles(context: Context, treeUri: Uri): List<AudioTrack> {
    val root = DocumentFile.fromTreeUri(context, treeUri) ?: return emptyList()
    val result = ArrayList<AudioTrack>()

    fun walk(directory: DocumentFile) {
        val files = try {
            directory.listFiles()
        } catch (_: Exception) {
            emptyArray<DocumentFile>()
        }

        for (file in files) {
            if (file.isDirectory) {
                walk(file)
            } else if (file.isFile) {
                val name = file.name ?: continue
                val extension = name.substringAfterLast('.', "").lowercase()

                if (extension in AUDIO_EXTENSIONS) {
                    val title = name.substringBeforeLast('.')
                    result += AudioTrack(
                        uri = file.uri,
                        title = title,
                        size = file.length()
                    )
                }
            }
        }
    }

    walk(root)

    return result.sortedBy { it.title.lowercase() }
}
