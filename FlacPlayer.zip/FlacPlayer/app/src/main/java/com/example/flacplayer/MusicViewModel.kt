package com.example.flacplayer

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.guava.await
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(
    name = "flac_player_settings"
)

private object PreferencesKeys {
    val TREE_URI = stringPreferencesKey("tree_uri")
}

data class UiState(
    val treeUri: Uri? = null,
    val tracks: List<AudioTrack> = emptyList(),
    val isScanning: Boolean = false,
    val errorMessage: String? = null,
    val isConnected: Boolean = false,
    val isPlaying: Boolean = false,
    val currentPosition: Long = 0L,
    val duration: Long = 0L,
    val currentTitle: String? = null,
    val currentIndex: Int = -1,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val shuffleEnabled: Boolean = false
)

class MusicViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private var controller: MediaController? = null
    private var desiredItems: List<MediaItem> = emptyList()
    private var progressJob: Job? = null
    private var scanJob: Job? = null

    private val serviceComponent = ComponentName(application, PlaybackService::class.java)

    private val controllerListener = object : MediaController.Listener() {

        override fun onDisconnected(controller: MediaController) {
            if (this@MusicViewModel.controller === controller) {
                this@MusicViewModel.controller = null
                _uiState.update {
                    it.copy(
                        isConnected = false,
                        isPlaying = false
                    )
                }
                progressJob?.cancel()
                progressJob = null
            }
        }

        override fun onEvents(controller: MediaController, events: Player.Events) {
            refreshPlayerState(controller)
        }
    }

    init {
        viewModelScope.launch {
            try {
                val future = MediaController.Builder(
                    getApplication(),
                    serviceComponent
                )
                    .setListener(controllerListener)
                    .buildAsync()

                val c = future.await()

                controller = c
                _uiState.update { it.copy(isConnected = true) }
                applyPlaylist()
                refreshPlayerState(c)
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                _uiState.update {
                    it.copy(
                        errorMessage = "No se pudo iniciar el motor de audio: ${t.message}"
                    )
                }
            }
        }

        viewModelScope.launch {
            getApplication<Application>().dataStore.data
                .catch { e ->
                    if (e is CancellationException) throw e
                    emit(emptyPreferences())
                }
                .map { it[PreferencesKeys.TREE_URI] }
                .distinctUntilChanged()
                .collect { uriString ->
                    val uri = uriString?.let(Uri::parse)

                    _uiState.update { it.copy(treeUri = uri) }

                    if (uri != null) {
                        loadFolder(uri)
                    } else {
                        desiredItems = emptyList()
                        _uiState.update {
                            it.copy(
                                tracks = emptyList(),
                                currentIndex = -1,
                                currentTitle = null,
                                duration = 0L,
                                currentPosition = 0L
                            )
                        }
                        applyPlaylist()
                    }
                }
        }
    }

    fun onFolderSelected(uri: Uri) {
        viewModelScope.launch {
            val context = getApplication<Application>()

            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // Algunos proveedores SAF pueden no permitir persistencia inmediata.
            }

            context.dataStore.edit { prefs ->
                prefs[PreferencesKeys.TREE_URI] = uri.toString()
            }
        }
    }

    fun reloadFolder() {
        _uiState.value.treeUri?.let { loadFolder(it) }
    }

    fun playTrack(index: Int) {
        _uiState.update {
            it.copy(
                currentIndex = index,
                currentTitle = it.tracks.getOrNull(index)?.title
            )
        }

        val c = controller

        if (c != null && c.isConnected && index in 0 until c.mediaItemCount) {
            c.seekTo(index, 0L)
            c.play()
        } else {
            applyPlaylist()
            controller?.play()
        }
    }

    fun togglePlayPause() {
        val c = controller ?: return

        if (c.mediaItemCount == 0) {
            applyPlaylist()
        }

        if (c.isPlaying) {
            c.pause()
        } else {
            c.play()
        }
    }

    fun skipNext() {
        controller?.seekToNextMediaItem()
    }

    fun skipPrevious() {
        controller?.seekToPreviousMediaItem()
    }

    fun seekTo(position: Long) {
        controller?.seekTo(position.coerceAtLeast(0L))
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun cycleRepeatMode() {
        val c = controller ?: return

        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
    }

    private fun loadFolder(uri: Uri) {
        scanJob?.cancel()

        _uiState.update {
            it.copy(
                isScanning = true,
                errorMessage = null
            )
        }

        scanJob = viewModelScope.launch {
            try {
                val tracks = withContext(Dispatchers.IO) {
                    scanAudioFiles(getApplication(), uri)
                }

                val items = tracks.map { it.toMediaItem() }
                desiredItems = items

                val newIndex = if (items.isEmpty()) -1 else 0

                _uiState.update {
                    it.copy(
                        tracks = tracks,
                        isScanning = false,
                        currentIndex = newIndex,
                        currentTitle = tracks.getOrNull(newIndex)?.title,
                        duration = 0L,
                        currentPosition = 0L
                    )
                }

                applyPlaylist()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isScanning = false,
                        errorMessage = "Error al leer la carpeta: ${e.message}"
                    )
                }
            }
        }
    }

    private fun applyPlaylist() {
        val c = controller ?: return

        if (!c.isConnected) return

        if (desiredItems.isEmpty()) {
            c.clearMediaItems()
            c.stop()
            return
        }

        val startIndex = _uiState.value.currentIndex.takeIf { it >= 0 } ?: 0
        val safeIndex = startIndex.coerceIn(0, desiredItems.lastIndex)

        c.setMediaItems(desiredItems, safeIndex, 0L)
        c.prepare()

        refreshPlayerState(c)
    }

    private fun refreshPlayerState(c: MediaController) {
        val rawDuration = c.duration
        val duration = if (rawDuration == C.TIME_UNSET || rawDuration < 0) {
            0L
        } else {
            rawDuration
        }

        val rawPosition = c.currentPosition
        val position = if (duration > 0) {
            rawPosition.coerceIn(0L, duration)
        } else {
            rawPosition.coerceAtLeast(0L)
        }

        val title = c.currentMediaItem?.mediaMetadata?.title?.toString()
            ?.takeIf { it.isNotBlank() }
            ?: c.currentMediaItem?.localConfiguration?.uri?.lastPathSegment
            ?: _uiState.value.tracks.getOrNull(c.currentMediaItemIndex)?.title

        _uiState.update {
            it.copy(
                isConnected = true,
                isPlaying = c.isPlaying,
                currentPosition = position,
                duration = duration,
                currentTitle = title,
                currentIndex = c.currentMediaItemIndex,
                repeatMode = c.repeatMode,
                shuffleEnabled = c.shuffleModeEnabled
            )
        }

        manageProgressJob()
    }

    private fun manageProgressJob() {
        val shouldRun = _uiState.value.isPlaying && controller != null

        if (shouldRun && progressJob?.isActive != true) {
            progressJob = viewModelScope.launch {
                while (isActive) {
                    delay(500L)
                    controller?.let { refreshPlayerState(it) }
                }
            }
        } else if (!shouldRun && progressJob != null) {
            progressJob?.cancel()
            progressJob = null
        }
    }

    override fun onCleared() {
        progressJob?.cancel()
        scanJob?.cancel()

        try {
            controller?.release()
        } catch (_: Exception) {
        }

        controller = null
        super.onCleared()
    }
}
