package com.example.flacplayer.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import com.example.flacplayer.AudioTrack
import com.example.flacplayer.MusicViewModel
import com.example.flacplayer.UiState
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicScreen(viewModel: MusicViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var showNowPlaying by remember { mutableStateOf(false) }

    val openFolder = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        uri?.let(viewModel::onFolderSelected)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("FLAC Player") },
                actions = {
                    TextButton(onClick = viewModel::reloadFolder) {
                        Text("Recargar")
                    }
                    TextButton(onClick = { openFolder.launch(null) }) {
                        Text("Carpeta")
                    }
                }
            )
        },
        bottomBar = {
            if (state.currentTitle != null) {
                PlayerBar(
                    state = state,
                    onToggle = viewModel::togglePlayPause,
                    onNext = viewModel::skipNext,
                    onPrevious = viewModel::skipPrevious,
                    onClick = { showNowPlaying = true }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when {
                state.isScanning -> {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center)
                    )
                }

                state.treeUri == null -> {
                    EmptyFolder(
                        onPickFolder = { openFolder.launch(null) }
                    )
                }

                state.tracks.isEmpty() -> {
                    CenteredMessage(
                        text = "No se encontraron archivos de audio compatibles."
                    )
                }

                else -> {
                    TrackList(
                        tracks = state.tracks,
                        currentIndex = state.currentIndex,
                        onPlay = viewModel::playTrack
                    )
                }
            }

            state.errorMessage?.let { message ->
                ErrorBanner(
                    message = message,
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
        }
    }

    if (showNowPlaying) {
        NowPlayingSheet(
            state = state,
            viewModel = viewModel,
            onDismiss = { showNowPlaying = false }
        )
    }
}

@Composable
private fun PlayerBar(
    state: UiState,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        tonalElevation = 3.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = state.currentTitle ?: "",
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = "${formatTime(state.currentPosition)} / ${formatTime(state.duration)}",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            TextButton(onClick = onPrevious) {
                Text("⏮")
            }

            FilledTonalButton(onClick = onToggle) {
                Text(if (state.isPlaying) "⏸" else "▶")
            }

            TextButton(onClick = onNext) {
                Text("⏭")
            }
        }
    }
}

@Composable
private fun TrackList(
    tracks: List<AudioTrack>,
    currentIndex: Int,
    onPlay: (Int) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize()
    ) {
        itemsIndexed(tracks) { index, track ->
            ListItem(
                headlineContent = {
                    Text(
                        text = track.title,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                supportingContent = {
                    Text(text = formatSize(track.size))
                },
                colors = if (index == currentIndex) {
                    ListItemDefaults.colors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                } else {
                    ListItemDefaults.colors()
                },
                modifier = Modifier.clickable { onPlay(index) }
            )
        }
    }
}

@Composable
private fun EmptyFolder(onPickFolder: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Elige la carpeta donde está tu música",
            style = MaterialTheme.typography.headlineSmall
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Compatible con FLAC, MP3, M4A, OGG, WAV, OPUS, etc.",
            style = MaterialTheme.typography.bodyMedium
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = onPickFolder) {
            Text("Seleccionar carpeta")
        }
    }
}

@Composable
private fun CenteredMessage(text: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = text)
    }
}

@Composable
private fun ErrorBanner(
    message: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer
        )
    ) {
        Text(
            text = message,
            modifier = Modifier.padding(12.dp),
            color = MaterialTheme.colorScheme.onErrorContainer
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NowPlayingSheet(
    state: UiState,
    viewModel: MusicViewModel,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = state.currentTitle ?: "",
                style = MaterialTheme.typography.headlineSmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(24.dp))

            var dragging by remember { mutableStateOf(false) }
            var dragFraction by remember { mutableFloatStateOf(0f) }

            val fraction = if (state.duration > 0) {
                if (dragging) {
                    dragFraction
                } else {
                    (state.currentPosition.toFloat() / state.duration.toFloat())
                        .coerceIn(0f, 1f)
                }
            } else {
                0f
            }

            Slider(
                value = fraction,
                onValueChange = {
                    dragging = true
                    dragFraction = it
                },
                onValueChangeFinished = {
                    dragging = false
                    if (state.duration > 0) {
                        viewModel.seekTo((dragFraction * state.duration).toLong())
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(formatTime(state.currentPosition))
                Text(formatTime(state.duration))
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextButton(onClick = viewModel::toggleShuffle) {
                    Text(
                        if (state.shuffleEnabled) {
                            "Aleatorio: ON"
                        } else {
                            "Aleatorio: OFF"
                        }
                    )
                }

                IconButton(onClick = viewModel::skipPrevious) {
                    Text("⏮")
                }

                FilledTonalButton(onClick = viewModel::togglePlayPause) {
                    Text(if (state.isPlaying) "⏸" else "▶")
                }

                IconButton(onClick = viewModel::skipNext) {
                    Text("⏭")
                }

                TextButton(onClick = viewModel::cycleRepeatMode) {
                    Text(repeatLabel(state.repeatMode))
                }
            }
        }
    }
}

private fun repeatLabel(mode: Int): String {
    return when (mode) {
        Player.REPEAT_MODE_ONE -> "Repetir: 1"
        Player.REPEAT_MODE_ALL -> "Repetir: todo"
        else -> "Repetir: OFF"
    }
}

private fun formatTime(milliseconds: Long): String {
    if (milliseconds <= 0) return "0:00"

    val totalSeconds = milliseconds / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60

    return String.format(Locale.getDefault(), "%d:%02d", minutes, seconds)
}

private fun formatSize(bytes: Long): String {
    if (bytes <= 0) return ""

    val units = listOf("B", "KB", "MB", "GB")
    var value = bytes.toDouble()
    var index = 0

    while (value >= 1024.0 && index < units.lastIndex) {
        value /= 1024.0
        index++
    }

    return String.format(Locale.getDefault(), "%.1f %s", value, units[index])
}
