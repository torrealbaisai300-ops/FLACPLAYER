package com.example.flacplayer

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class AudioTrack(
    val uri: Uri,
    val title: String,
    val size: Long
)

fun AudioTrack.toMediaItem(): MediaItem {
    return MediaItem.Builder()
        .setUri(uri)
        .setMediaId(uri.toString())
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .build()
        )
        .setMediaType(MediaItem.MEDIA_TYPE_AUDIO)
        .build()
}
